package com.androstock.IotSchoolBag;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Registration extends AppCompatActivity {

    private EditText edit_names;
    private EditText edit_username;
    private EditText edit_mail;
    private EditText edit_password;
    private EditText confirm_password;
    private Button signUp;

    private  static  final  String REGISTER_URL="http://iotschoolbag.000webhostapp.com/register.php";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        edit_names = (EditText)findViewById(R.id.txtNames);
        edit_username = (EditText)findViewById(R.id.txtUsername);
        edit_mail = (EditText)findViewById(R.id.txtEmail);
        edit_password = (EditText)findViewById(R.id.txtPassword);
        confirm_password = (EditText)findViewById(R.id.CPassword);
        signUp = (Button)findViewById(R.id.btn_Register);
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

    }

    private  void registerUser()
    {
        String fullNames = edit_names.getText().toString().trim().toLowerCase();
        String username = edit_username.getText().toString().trim().toLowerCase();
        String email = edit_mail.getText().toString().trim().toLowerCase();
        String password = edit_password.getText().toString().trim().toLowerCase();

        if(!inputValidete(fullNames,username,email,password)){
            Toast.makeText(this,"Registration has failed!",Toast.LENGTH_SHORT).show();
        }else if(validatePassword() == false){
            Toast.makeText(Registration.this, "Password Not matching", Toast.LENGTH_SHORT).show();

        }else{
            register(fullNames,username,email,password);
        }
    }

    private boolean validatePassword()
    {
        boolean temp = true;
        String password = edit_password.getText().toString().trim().toLowerCase();
        String cpassword = confirm_password.getText().toString().trim().toLowerCase();

        if(!password.equals(cpassword))
        {
            Toast.makeText(Registration.this, "Password Not matching", Toast.LENGTH_SHORT).show();
            temp = false;
        }
        return temp;
    }

    private boolean inputValidete(String fullNames,String username,String email,String password)
    {
        boolean checkInput = true;

        if(fullNames.isEmpty()||fullNames.length()>50)
        {
            edit_names.setError("Please Enter valid names");
            checkInput = false;
        }
        if(username.isEmpty()||username.length()>50)
        {
            edit_username.setError("Please Enter valid username");
            checkInput=false;
        }
        if(email.isEmpty()||email.length()>50)
        {
            edit_mail.setError("Please Enter valid Email Address");
            checkInput=false;
        }
        if(password.isEmpty()||password.length() <8 ||password.length()>20)
        {
            edit_password.setError("Please Enter valid password");
            checkInput=false;
        }
        return checkInput;
    }

    private  void register(String fNames,String uName,String mail,String passwrd){
        String urlsuffix ="?fullNames="+fNames+"&username="+uName+"&email="+mail+"&password="+passwrd;

        class userRegistration extends AsyncTask<String,Void,String> {

            ProgressDialog loading;
            @Override
            protected  void onPreExecute(){
                super.onPreExecute();
                loading=ProgressDialog.show(Registration.this,"Please Wait",null,true,true);
                loading.setCancelable(false);
                loading.show();
            }

            @Override
            protected void onPostExecute(String s){
                super.onPostExecute(s);
                Toast.makeText(getApplicationContext(), "Successfully Registered!", Toast.LENGTH_SHORT).show();

                loading.dismiss();
                Intent intent = new Intent(Registration.this, Login.class);
                startActivity(intent);
                Registration.this.finish();

                if(s.equalsIgnoreCase("false")){
                    Toast.makeText(Registration.this,"Invalid email or username",Toast.LENGTH_LONG).show();

                }
                else  if ( s.equalsIgnoreCase("exception")||s.equalsIgnoreCase("unsuccessful")){
                    Toast.makeText(Registration.this,"OOPs! Something went wrong. Connection Problem.",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            protected String doInBackground(String... strings) {

                String s = strings[0];
                BufferedReader bufferedReader = null;

                try{
                    URL url = new URL(REGISTER_URL+s);
                    HttpURLConnection con = (HttpURLConnection)url.openConnection();
                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String result;
                    result = bufferedReader.readLine();
                    return  result;
                }catch (Exception e){
                    return null;
                }

            }
        }
        userRegistration ur = new userRegistration();
        ur.execute(urlsuffix);
    }
}
