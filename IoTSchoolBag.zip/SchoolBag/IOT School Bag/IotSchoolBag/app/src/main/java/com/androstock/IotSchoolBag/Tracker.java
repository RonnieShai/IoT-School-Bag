package com.androstock.IotSchoolBag;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;

public class Tracker extends FragmentActivity implements OnMapReadyCallback {

    private final static int MY_PERMISSION_FINE_LOCATION = 101;
    final static int PERMISSION_ALL = 1;
    final static String[] PERMISSIONS = {android.Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION};
    private GoogleMap mMap;
    double lat;
    double lng;
    double latitude;
    double longitude;
    private Button CloseMap;
    private Button logOff;

    public LocationManager locationManager;
    public Criteria criteria;
    public String bestProvider;

    String voice2text; //added

    ArrayList<LatLng> listPoints;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        listPoints = new ArrayList<>();

        CloseMap = (Button)findViewById(R.id.btnClose);

        CloseMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Tracker.this, TaskHome.class);
                startActivity(intent);
                Tracker.this.finish();
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        new Connection().execute();

        mMap.getUiSettings().setZoomControlsEnabled(true);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            mMap.setMyLocationEnabled(true);
            LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
            Criteria criteria = new Criteria();

            //---------------Edit--------------
            // bestProvider = String.valueOf(locationManager.getBestProvider(criteria, true)).toString();
            // Location location = locationManager.getLastKnownLocation(locationManager.getBestProvider(criteria, false));
            Location location = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);
            //Location location = locationManager.getLastKnownLocation(bestProvider);

            latitude = location.getLatitude();
            longitude = location.getLongitude();
            LatLng My = new LatLng(latitude, longitude);

            //  mMap.addMarker(new MarkerOptions().position(My).title("Maidi"));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(My,18));
            listPoints.add(My);

            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(My);

        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSION_FINE_LOCATION);
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSION_FINE_LOCATION:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        mMap.setMyLocationEnabled(true);

                    }

                } else {
                    Toast.makeText(getApplicationContext(), "This app requires location permissions to be granted", Toast.LENGTH_LONG).show();
                    finish();
                }
                break;
        }
    }


    private void addLatLng(double lat,double lng) {
        // Add a marker in South Africa and move the camera
        LatLng Yvonne = new LatLng(lat,lng);
        mMap.addMarker(new MarkerOptions().position(Yvonne).title("My Child"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(Yvonne,18));
    }

    public void onZoom(View view)
    {
        if(view.getId()== R.id.btnZoomIn)
        {
            mMap.animateCamera(CameraUpdateFactory.zoomIn());
        }
        if(view.getId() == R.id.btnZoomOut)
        {
            mMap.animateCamera(CameraUpdateFactory.zoomOut());
        }
    }

    public void onChangeType(View view)
    {
        if(mMap.getMapType() == GoogleMap.MAP_TYPE_NORMAL)
        {
            mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
        }
        else if(mMap.getMapType() == GoogleMap.MAP_TYPE_SATELLITE){

            mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        }
        else if(mMap.getMapType() == GoogleMap.MAP_TYPE_HYBRID){
            mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        }
        else{
            mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        }
    }

    class Connection extends AsyncTask<String,String,String> {

        private Connection connection;
        @Override
        protected String doInBackground(String... params) {

            String result ="";
            String host = "http://iotschoolbag.000webhostapp.com/test.php";

            try{
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(host));

                org.apache.http.HttpResponse response = client.execute(request);
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

                StringBuffer stringBuffer = new StringBuffer("");
                String line ="";
                while((line = reader.readLine()) != null){
                    stringBuffer.append(line);
                    break;
                }

                reader.close();;
                result = stringBuffer.toString();

            }catch(Exception e)
            {
                return  new String("There exception: "+ e.getMessage());
            }

            return result;
        }

        @Override
        protected void onPostExecute(String result)
        {
            try {
                JSONObject jsonResult = new JSONObject(result);
                int success = jsonResult.getInt("success");

                if(success == 1){
                    Toast.makeText(getApplicationContext(),"Location found",Toast.LENGTH_SHORT).show();

                    JSONArray datas = jsonResult.getJSONArray("datas");

                    for(int i = 0;i<datas.length();i++)
                    {
                        JSONObject data = datas.getJSONObject(i);
                        lat = data.getDouble("latitude");
                        lng = data.getDouble("longitude");
                        addLatLng(lat,lng);
                    }
                }else{
                    Toast.makeText(getApplicationContext(),"Location not found",Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
            }

        }
    }
}
