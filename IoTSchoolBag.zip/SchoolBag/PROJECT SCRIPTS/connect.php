<?php

	function Connection(){
		$server="localhost";
		$user="id9700468_dbdata";
		$pass="214278056";
		$db="id9700468_persondb";
		

		$connection = mysqli_connect($server, $user, $pass,$db);

		if (!$connection) {
	    	die('MySQL ERROR: ' . mysqli_error());
		}
	/*	else{
			echo"connected ";
		}*/
		
		mysqli_select_db($connection,$db) or die( 'MySQL ERROR: '. mysqli_error() );

		return $connection;
	}
?>