<?php 
	include("connect.php");
   	
	$link=Connection();
	
	if($_SERVER['REQUEST_METHOD']=='POST'){
	$username = $_POST['username'];
		
	$password = $_POST['password'];
	$sql = "SELECT * FROM Parent WHERE username='$username' AND password='$password'";
	
	$result = mysqli_query($link,$sql);
	$check = mysqli_fetch_array($result);
	
	if(isset($check))
	{
	echo "success";
	}
	else{
	echo "failure";
	}
		mysqli_close($link);
	}
?>