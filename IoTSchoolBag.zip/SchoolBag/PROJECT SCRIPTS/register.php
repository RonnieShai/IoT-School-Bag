<?php
       
        define('HOST','localhost');
        define('USER','id9700468_dbdata');
       	define('PASS','214278056');
		define('DB','id9700468_persondb');
	
        $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
		
		$fullNames = $_GET['fullNames'];
        $username = $_GET['username'];
		$email = $_GET['email'];
	
		$password = $_GET['password'];
	
		
		
		
		if($fullNames =='' ||$username == '' || $email == ''|| $password == '' )
		{
	
		echo 'please fill all values';
		}
		else{
		$sql = "SELECT * FROM Parent WHERE fullNames='$fullNames' OR username='$username' OR email='$email'";
	        $check = mysqli_fetch_array(mysqli_query($con,$sql));
		if(isset($check)){
		echo 'username or email already exist';
		}else{
		$sql = "INSERT INTO Parent (fullNames,username,email,password) VALUES('$fullNames','$username','$email','$password')";
		if(mysqli_query($con,$sql)){
			echo 'successfully registered';
	
	}
		else{
				
			echo 'oops! Please try again!';
		
		}
}
			
	        mysqli_close($con);
		}	
	?>