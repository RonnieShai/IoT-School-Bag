<?php
   	include("connect.php");
   	
   	$link=Connection();

	$response = array();
	
	$sql = "SELECT latitude,longitude from DATA_SAVE order by timestamp DESC LIMIT 1";
	
	$Result = mysqli_query($link,$sql);
	
	if(mysqli_num_rows($Result) > 0){
	    
	    $response['success'] = 1;
	    
	    $datas = array();
		while($row = mysqli_fetch_assoc($Result)){
			array_push($datas,$row);
		}
		
		$response['datas'] = $datas;
	}else{
		
		$response['success'] = 0;
		$response['message']='No data';
	}
	
	echo json_encode($response);
  
	mysqli_close($link);

   	
?>